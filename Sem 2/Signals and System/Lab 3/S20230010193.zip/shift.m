function [y,n] = shift(x,m,a)
n = m+a;
y=x;