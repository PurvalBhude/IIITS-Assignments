function[y,n] = fold(x,m)
n = -1*fliplr(m);
y = fliplr(x);