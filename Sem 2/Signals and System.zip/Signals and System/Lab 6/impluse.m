function x = impluse(n)
x = n==0;
end