function x = unit(n)
x = n>=0;
end