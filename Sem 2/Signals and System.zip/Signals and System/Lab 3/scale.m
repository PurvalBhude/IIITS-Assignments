function [y,n] = scale(x,m,b)
n = m/b;
y=x;